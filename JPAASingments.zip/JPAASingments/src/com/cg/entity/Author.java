package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Author")
public class Author {
	@Id
	@Column(name="AuthorId")
private  int AuthorId;
	@Column(name="FirstName")
private String FirstName;
	@Column(name="MiddleName")
private String MiddleName;
	@Column(name="LastName")
private String LastName;
	@Column(name="phoneNo")
private Long PhoneNo;

public int getAuthorId() {
	return AuthorId;
}

public void setAuthorId(int authorId) {
	AuthorId = authorId;
}

public String getFirstName() {
	return FirstName;
}

public void setFirstName(String firstName) {
	FirstName = firstName;
}

public String getMiddleName() {
	return MiddleName;
}

public void setMiddleName(String middleName) {
	MiddleName = middleName;
}

public String getLastName() {
	return LastName;
}

public void setLastName(String lastName) {
	LastName = lastName;
}

public Long getPhoneNo() {
	return PhoneNo;
}

public void setPhoneNo(Long phoneNo) {
	PhoneNo = phoneNo;
}

@Override
public String toString() {
	return "Author [AuthorId=" + AuthorId + ", FirstName=" + FirstName + ", MiddleName=" + MiddleName + ", LastName="
			+ LastName + ", PhoneNo=" + PhoneNo + "]";
}
public Author() {
}

}
