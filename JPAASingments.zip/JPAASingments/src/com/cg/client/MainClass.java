package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager=factory.createEntityManager();
		manager.getTransaction().begin();
		Author aut=new Author();
		aut.setAuthorId(1001);
		aut.setFirstName("Ravindar");
		aut.setMiddleName("Singh");
		aut.setLastName("jogi");
		aut.setPhoneNo( 9791715813l);
		manager.persist(aut);
		
		Author aut1=new Author();
		aut1.setAuthorId(1002);
		aut1.setFirstName("chetan");
		aut1.setMiddleName("Bhagat");
		aut1.setLastName("thoa");
		aut1.setPhoneNo( 9791715885l);
		manager.persist(aut1);

		Author aut2=new Author();
		aut2.setAuthorId(1003);
		aut2.setFirstName("Ravindarnath");
		aut2.setMiddleName("Tagore");
		aut2.setLastName("sign");
		aut2.setPhoneNo(9847565255l);
		manager.persist(aut2);
		
		manager.close();
		System.out.println("added details");
		manager.getTransaction().commit();
		factory.close();
	}
}
