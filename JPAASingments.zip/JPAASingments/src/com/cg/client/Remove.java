package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class Remove {


		public static void main(String[] args) {

		EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager manager= factory.createEntityManager();

		manager.getTransaction().begin();

		Author aut= manager.find(Author.class, 1001);
		
		
		manager.remove(aut);

		System.out.println(aut.getAuthorId()+" Entry has been removed");

		manager.getTransaction().commit();

		manager.close();

		factory.close();

		}

		}


