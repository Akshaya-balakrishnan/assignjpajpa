package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class Update {

	public static void main(String[] args) {
		EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager manager= factory.createEntityManager();

		manager.getTransaction().begin();
		Author aut1= manager.find(Author.class, 1002);
		aut1.setFirstName("kettan");
		manager.merge(aut1);
		System.out.println(aut1.getFirstName()+" Is the New FirstName of Author ");
		manager.getTransaction().commit();
		manager.close();
		factory.close();
	}

}
